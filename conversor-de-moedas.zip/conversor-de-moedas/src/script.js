function Converter() {
  var valorElemento = document.getElementById("valor");
  var valor = valorElemento.value;
  var valorEmDolarNumerico = parseFloat(valor);

  var valorEmReal = valorEmDolarNumerico * 5;
  console.log(valorEmReal);
  var valorEmEuro = valorEmDolarNumerico * 0.85;
  console.log(valorEmEuro);
  var valorEmBitcoin = valorEmDolarNumerico * 0.000021;
  console.log(valorEmBitcoin);

  var elementoValorConvertidoReal = document.getElementById(
    "valorConvertidoReal"
  );
  var valorConvertidoReal = "O resultado em Real é: R$" + valorEmReal;
  elementoValorConvertidoReal.innerHTML = valorConvertidoReal;

  var elementoValorConvertidoEuro = document.getElementById(
    "valorConvertidoEuro"
  );
  var valorConvertidoEuro = "O resultado em Euro é: €" + valorEmEuro;
  elementoValorConvertidoEuro.innerHTML = valorConvertidoEuro;

  var elementoValorConvertidoBitcoin = document.getElementById(
    "valorConvertidoBitcoin"
  );
  var valorConvertidoBitcoin =
    "O resultado em Bitcoin é de: Btc" + valorEmBitcoin;
  elementoValorConvertidoBitcoin.innerHTML = valorConvertidoBitcoin;
}
